# GARAGE LAYOUT PLANNER - PROJECT HANDOFF
## Version 1.0 Complete | December 13, 2024

---

## PROJECT OVERVIEW

A Python-based garage planning tool that helps homeowners:
1. Capture garage dimensions and features
2. Define usage needs (vehicles, storage, workspace)
3. Generate optimized floor layouts
4. Create build plans with cut lists and shopping lists
5. Visualize the layout as a PNG floor plan

**Target User:** Homeowner planning to organize/build out their garage
**Current State:** Fully functional CLI tool, ready for v2.0 enhancements

---

## FILE INVENTORY

### Core Application Files

| File | Phase | Purpose | Status |
|------|-------|---------|--------|
| `garage_intake_v2_1.py` | 1 | Captures garage dimensions, doors, windows, electrical | ✓ Complete |
| `Garage_usage.py` | 2 | Captures vehicles, storage needs, work activities, priorities | ✓ Complete |
| `garage_optimizer.py` | 3 | Generates optimized layout based on constraints & priorities | ✓ Complete |
| `generate_build_plans.py` | 4 | Creates cut lists, materials lists, step-by-step instructions | ✓ Complete |
| `generate_floorplan.py` | Visual | Generates PNG floor plan from recommendation | ✓ Complete |
| `vehicle_database.py` | Support | Vehicle dimensions lookup | ✓ Complete |

### Data Files (Generated)

| File | Format | Purpose |
|------|--------|---------|
| `garage_layout.txt` | Text | Phase 1 output - dimensions & features |
| `garage_usage.json` | JSON | Phase 2 output - usage profile |
| `garage_recommendation.txt` | Text | Phase 3 output - layout recommendation |
| `garage_build_plans.txt` | Text | Phase 4 output - build instructions |
| `garage_floorplan.png` | PNG | Visual floor plan |

### Dependencies

```
Python 3.10+
Pillow (PIL) - for PNG generation
```

Install: `pip install Pillow`

---

## HOW TO RUN

### Full Workflow
```bash
# Step 1: Capture garage dimensions
python garage_intake_v2_1.py

# Step 2: Capture usage needs  
python Garage_usage.py

# Step 3: Generate optimized layout
python garage_optimizer.py

# Step 4: Generate build plans
python generate_build_plans.py

# Step 5: Generate visual floor plan
python generate_floorplan.py
```

### Quick Test (after initial setup)
```bash
python garage_optimizer.py && python generate_floorplan.py
```

---

## CURRENT FEATURES (v1.0)

### Phase 1 - Garage Intake
- Garage dimensions (width, depth, ceiling height)
- Wall orientation
- Garage door size and position
- Entry/service doors
- Windows (with positions)
- Electrical panel location
- Existing features

### Phase 2 - Usage Profile
- Vehicle information (make, model, year, must-fit flag)
- Storage categories with access frequency
- Work activities
- Priority rankings (1-5) for workspace, storage, etc.
- Preferences (wall storage, overhead, workbench)

### Phase 3 - Layout Optimizer
- Constraint-based placement (door clearances, electrical access)
- Priority-weighted zone placement
- Multi-vehicle side-by-side positioning
- Wall storage distribution across N/E/W walls
- Overhead storage platform placement
- ASCII diagram output
- Detailed recommendation report

### Phase 4 - Build Plans
- Advanced workbench (8' with drawers, pegboard, power strip)
- French cleat wall storage system
- Overhead storage platform
- Cut lists with dimensions
- Materials lists with costs
- Step-by-step assembly instructions
- Budget tracking (~$341 for full build)

### Visual Output
- Scaled PNG floor plan
- Color-coded zones (vehicle, workbench, storage, overhead)
- Grid overlay (2' spacing)
- Dimension labels
- Legend

---

## ROADMAP

### v1.1 - Interactive Build Planner (Next)
- [ ] Add questionnaire to Phase 4:
  - Budget input ("What's your budget?")
  - Workbench style choice (basic / advanced / cabinet)
  - Wall storage type (french cleats / slat wall / pegboard / shelving)
  - Overhead platform count and placement
- [ ] Allow multiple iterations ("Want to adjust and regenerate?")
- [ ] Inventory tracker:
  - "Do you have lumber on hand?" 
  - "Hardware inventory?"
  - "Tools available?"
  - Subtract from shopping list
  - Flag tool rentals needed
- [ ] Project phasing (what to build first/second/third)

### v1.2 - Enhanced Outputs
- [ ] Export shopping list as separate file
- [ ] Generate PDF report (combined recommendation + build plans)
- [ ] SVG floor plan option (scalable)
- [ ] Multiple layout alternatives ("Option A, B, C")

### v2.0 - Mobile App Foundation
- [ ] Convert to web app (Flask/FastAPI backend)
- [ ] Responsive UI (works on phone/tablet)
- [ ] Save/load projects
- [ ] User accounts (optional)
- [ ] Share layouts via link

### v2.1 - Mobile Native
- [ ] React Native or Flutter app
- [ ] Offline capability
- [ ] Touch-friendly interface
- [ ] Camera integration for photos
- [ ] Local storage for projects

### v3.0 - Computer Vision & AR (Future)
- [ ] **Photo Capture**: Take photos of garage
- [ ] **Auto-Measurement**: 
  - Use phone LiDAR (iPhone Pro) or ARCore/ARKit
  - Detect walls, doors, windows from photos
  - Estimate dimensions from reference objects
  - Manual adjustment/correction UI
- [ ] **Augmented Reality Visualization**:
  - Preview workbench placement in real space
  - See storage zones overlaid on camera view
  - Walk through proposed layout
  - "What fits here?" interactive mode
- [ ] **Photo Documentation**:
  - Before/after comparisons
  - Progress tracking
  - Inventory photos (what you have)

### v3.1 - AI Enhancements
- [ ] Smart suggestions based on garage photos
- [ ] "Similar garages" inspiration gallery
- [ ] Voice input for dimensions
- [ ] Natural language queries ("Where should I put my bike?")

---

## TECHNICAL NOTES

### Architecture Decisions

**Why CLI first?**
- Fastest to iterate
- No UI complexity
- Easy to test logic
- Foundation for any frontend

**Why JSON for usage profile?**
- Structured data for optimizer
- Easy to edit manually
- Portable between systems
- API-ready format

**Why ASCII + PNG?**
- ASCII: Quick preview, works anywhere
- PNG: Shareable, printable, professional

### Key Algorithms

**Layout Optimizer (garage_optimizer.py)**
- Greedy placement algorithm
- Sorts zones by priority, places highest first
- Collision detection with `rectangles_overlap()`
- Position validation with `position_is_clear()`
- Constraint generation from features (clearance zones)

**Measurement Parsing**
- Handles: `10'6"`, `184.1"`, `6 3/4"`, plain numbers
- Regex-based with decimal support
- Function: `measurement_to_inches()`

**Vehicle Placement**
- Single vehicle: 24" clearance both sides
- Multiple vehicles: 24" outer edges, 12" gap between
- Pulls in from garage door (south wall)

### Constants (inches)

```python
CLEARANCES = {
    "garage_door": 36,
    "entry_door": 36,
    "electrical_panel": 36,
    "vehicle_side": 24,
    "vehicle_between": 12,
    "workbench_front": 36,
    "walkway": 30,
    "overhead_min_height": 84,  # 7 feet
}

ZONE_SIZES = {
    "workbench_large": {"width": 96, "depth": 30},  # 8' x 2.5'
    "workbench_medium": {"width": 72, "depth": 30},
    "workbench_small": {"width": 48, "depth": 24},
    "wall_storage_section": {"width": 48, "depth": 18},
    "overhead_depth": 48,  # 4' from wall
}
```

---

## KNOWN ISSUES / LIMITATIONS

1. **Window constraints on west wall** - Optimizer places storage at 0' from north even when windows are present. Need to parse window Y positions.

2. **Single vehicle only in user's data** - Second vehicle had `must_fit_inside: false`. User must edit JSON or re-run Phase 2.

3. **Hardcoded build options** - Phase 4 doesn't ask questions yet, uses fixed advanced workbench + french cleats.

4. **No persistence** - Each run overwrites previous files. No project save/load.

5. **Prices are estimates** - Lumber prices vary by region and time. Should add price update mechanism.

---

## TEST DATA (Mike's Garage)

```
Dimensions: 25' x 25' x 12'2" ceiling
Vehicles: 2019 Hyundai Elantra (must fit), 2018 Nissan Altima (optional)
Storage priority: 5/5
Workspace priority: 5/5
Features: 16' garage door, 2 entry doors, 2 windows, electrical panel on south wall
```

**Optimized Layout Result:**
- 1 vehicle (Elantra) centered
- 8' workbench on north wall
- 20 wall storage sections (N/E/W walls)
- 3 overhead platforms
- Score: 100/100

---

## CONTACT / CONTINUATION

This project was developed in a Claude AI session on December 13, 2024.

To continue development:
1. Load this handoff document
2. Reference the file inventory
3. Pick a roadmap item
4. Describe desired changes

**Session Summary Prompt:**
> "I'm continuing development on the Garage Layout Planner. It's a Python CLI tool with 4 phases: intake, usage, optimizer, build plans. Current version is 1.0 complete. I want to work on [ROADMAP ITEM]. Here are the existing files: [LIST FILES]"

---

## QUICK REFERENCE

### Run Everything
```bash
python garage_intake_v2_1.py
python Garage_usage.py
python garage_optimizer.py
python generate_build_plans.py
python generate_floorplan.py
```

### Output Files
- `garage_recommendation.txt` - Layout details
- `garage_build_plans.txt` - Build instructions
- `garage_floorplan.png` - Visual diagram

### Budget Summary (v1.0 defaults)
- Workbench: ~$155
- French Cleats: ~$86
- Overhead Platform: ~$100
- **Total: ~$341**

---

*End of Handoff Document*
